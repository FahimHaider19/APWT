export class EmployeeDTO {
  userId: number;
  name: string;
  email: string;
  password: string;
  role: string;
}