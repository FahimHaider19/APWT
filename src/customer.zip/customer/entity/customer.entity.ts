import { Entity, PrimaryGeneratedColumn, Column, OneToMany } from 'typeorm';
import { Cart } from './customer-cart.entity';
import { Wishlist } from './customer-wishlist.entity';

@Entity('customer')
export class Customer {
  @PrimaryGeneratedColumn()
  userId: number;

  @Column()
  name: string;

  @Column()
  email: string;

  @Column()
  password: string;

  @Column({ default: 'customer' })
  role: string;
 
  @OneToMany(type => Wishlist, wishlist => wishlist.customer)
  wishlist: string;
  
  @OneToMany(type => Cart, cart => cart.customer)
  cart: string;
  
  // @OneToMany(type => Orders, orders => orders.customer)
  // orders: string;
}
